#!/bin/sh

gbp buildpackage --git-upstream-branch=master --git-upstream-tree=branch -S
