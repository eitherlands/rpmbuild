#!/bin/sh

exec autoreconf -fi
