struct base64_test_row { const unsigned char native[17]; const char encoded[25]; };
typedef base64_test_row *base64_test_vector;
extern base64_test_row static_base64_vector[];
